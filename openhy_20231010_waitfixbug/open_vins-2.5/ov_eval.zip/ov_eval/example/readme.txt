

This is some example data to test the evaluation on.
This is from the rpg_trajectory_evaluation toolbox.

https://github.com/uzh-rpg/rpg_trajectory_evaluation


This is the "vio_mono" for "MH_01" which corresponds to a single run of VINS-Mono on the EuRoC Mav machine hall 01 dataset.
We use this to ensure that our toolbox produces the same values as the rpg_trajectory_evaluation toolbox.




